# Ultimate Discord Community Bot — v3

A configurable Discord.js v14 project starter featuring:
- Moderation: kick, ban, unban, timeout, remove timeout, quarantine, remove quarantine
- Moderation DMs, case numbers, moderation log channel
- Ticket panel, claim, add/remove user, close, and HTML transcript export
- Chat/voice XP, rank and leaderboard
- Auto roles and reaction roles
- Welcome/goodbye and server event logs
- Anti-spam (bursts, repeated messages, excessive mentions/links)
- Anti-raid join-rate detection with alert or optional quarantine action
- Anti-nuke monitoring for mass channel/role deletions and bans; alert by default, optional kick response
- Button + modal math verification flow
- OAuth2 web dashboard with server selection and settings form
- Per-guild configuration stored in JSON files

## Requirements
- Node.js 20+
- Discord application/bot and a test server
- Enable **Server Members Intent** and **Message Content Intent** in Developer Portal. Enable **Presence Intent** for staff presence snapshot.
- Bot invite scopes: `bot`, `applications.commands`. Give only permissions needed.
- For dashboard, configure OAuth2 redirect URI exactly as `DASHBOARD_URL/auth/callback`.

## Start
1. Copy `.env.example` to `.env`, fill values.
2. `npm install`
3. Configure IDs in `config.json` or dashboard.
4. `npm run deploy`
5. Run bot: `npm start`
6. In a second terminal run dashboard: `npm run dashboard`
7. Visit `http://localhost:3000`

The dashboard uses Discord OAuth2. Add the redirect URL in Developer Portal > OAuth2. Do not expose your client secret or session secret. Use HTTPS and a strong SESSION_SECRET for public hosting.

## Important
- This is a feature-rich starter, not a fully audited security product. Test in a private server first.
- Anti-nuke actions default to `alert`; audit-log attribution can be delayed or ambiguous. Carefully test before enabling automatic enforcement.
- The verification flow is a basic math challenge, not a robust CAPTCHA or proof-of-human system.
- JSON storage is for small servers and demos. For high traffic/multiple instances, replace it with a database.
- The dashboard only shows servers where the logged-in user has Manage Server permission and the bot is installed.
- Quarantine and verified roles must be created/configured with correct channel overwrites and role hierarchy.
- Ticket transcripts are posted as HTML attachments to the configured log channel. Do not log sensitive information without informing your community.
- Never commit `.env` or share your bot token.

require("dotenv").config();
const express = require("express");
const session = require("express-session");
const crypto = require("node:crypto");
const { guildConfig } = require("../src/config");
const storage = require("../src/storage");
const app = express();
const PORT = Number(process.env.PORT || 3000);
const base = (process.env.DASHBOARD_URL || `http://localhost:${PORT}`).replace(/\/$/,"");
const clientId = process.env.CLIENT_ID, clientSecret = process.env.DISCORD_CLIENT_SECRET;
if (!clientId || !clientSecret || !process.env.SESSION_SECRET) {
  console.warn("Dashboard OAuth configuration missing. Set CLIENT_ID, DISCORD_CLIENT_SECRET, SESSION_SECRET in .env.");
}
app.set("trust proxy", 1);
app.use(express.urlencoded({extended:false}));
app.use(session({secret:process.env.SESSION_SECRET||crypto.randomBytes(32).toString("hex"),resave:false,saveUninitialized:false,cookie:{httpOnly:true,sameSite:"lax",secure:base.startsWith("https://"),maxAge:8*60*60*1000}}));
const esc = s => String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const page = (title,body,user=null) => `<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>${esc(title)}</title><style>
:root{color-scheme:dark}body{font-family:system-ui,Arial;background:#0b1020;color:#e5e7eb;margin:0}header{padding:18px 5vw;background:#111a30;border-bottom:1px solid #26324c;display:flex;justify-content:space-between;align-items:center}main{max-width:900px;margin:35px auto;padding:0 20px}.card{background:#131d33;border:1px solid #293650;border-radius:14px;padding:22px;margin:16px 0}a,button{color:white;background:#5865f2;border:0;border-radius:8px;padding:10px 14px;text-decoration:none;cursor:pointer}input,select{display:block;box-sizing:border-box;width:100%;padding:10px;margin:6px 0 16px;border-radius:7px;border:1px solid #3a4966;background:#0b1020;color:#fff}label{font-weight:600}small,.muted{color:#a9b4cc}.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(240px,1fr));gap:12px}.pill{display:inline-block;background:#263650;border-radius:30px;padding:5px 10px;margin:4px}.danger{background:#9b2c3b}</style></head><body><header><strong>🛡️ Ultimate Community Bot</strong><span>${user?`Signed in as ${esc(user.username)} · <a href="/logout">Log out</a>`:""}</span></header><main>${body}</main></body></html>`;
function requireAuth(req,res,next){if(!req.session.user)return res.redirect("/");next();}
app.get("/",(req,res)=>{
 if(!req.session.user) return res.send(page("Ultimate Dashboard",`<section class="card"><h1>Discord Community Dashboard</h1><p class="muted">Manage configuration for servers where you have Manage Server permission and the bot is installed.</p><p><a href="/auth/login">Sign in with Discord</a></p></section>`));
 res.redirect("/servers");
});
app.get("/auth/login",(req,res)=>{
 if(!clientId||!clientSecret)return res.status(500).send(page("Setup required","<h1>Dashboard setup required</h1><p>Set CLIENT_ID and DISCORD_CLIENT_SECRET in .env.</p>"));
 const state=crypto.randomBytes(24).toString("hex");req.session.oauthState=state;
 const params=new URLSearchParams({client_id:clientId,redirect_uri:`${base}/auth/callback`,response_type:"code",scope:"identify guilds",state});
 res.redirect(`https://discord.com/oauth2/authorize?${params}`);
});
app.get("/auth/callback",async(req,res)=>{
 if(!req.query.code||!req.query.state||req.query.state!==req.session.oauthState)return res.status(400).send("Invalid OAuth state. Please retry login.");
 try{
  const tokenRes=await fetch("https://discord.com/api/oauth2/token",{method:"POST",headers:{"Content-Type":"application/x-www-form-urlencoded"},body:new URLSearchParams({client_id:clientId,client_secret:clientSecret,grant_type:"authorization_code",code:req.query.code,redirect_uri:`${base}/auth/callback`})});
  const token=await tokenRes.json();if(!token.access_token)throw new Error("OAuth token exchange failed");
  const headers={Authorization:`Bearer ${token.access_token}`};
  const [meRes,guildRes]=await Promise.all([fetch("https://discord.com/api/users/@me",{headers}),fetch("https://discord.com/api/users/@me/guilds",{headers})]);
  const me=await meRes.json(),guilds=await guildRes.json();
  req.session.user={id:me.id,username:me.global_name||me.username,avatar:me.avatar};
  req.session.guilds=Array.isArray(guilds)?guilds.filter(g=>(BigInt(g.permissions)&BigInt(0x20))===BigInt(0x20)||g.owner):[];
  req.session.save(()=>res.redirect("/servers"));
 }catch(e){console.error(e);res.status(500).send(page("Login failed","<h1>Discord login failed</h1><p>Please check OAuth configuration and try again.</p>"));}
});
app.get("/servers",requireAuth,(req,res)=>{
 const guilds=req.session.guilds||[];
 const body=`<h1>Your manageable servers</h1><p class="muted">Only servers where you have Manage Server permission are listed. The bot must also be installed to apply settings.</p><div class="grid">${guilds.map(g=>`<section class="card"><h3>${esc(g.name)}</h3><p><span class="pill">ID: ${esc(g.id)}</span></p><a href="/servers/${encodeURIComponent(g.id)}">Open settings</a></section>`).join("")||"<p>No manageable servers were returned by Discord.</p>"}</div>`;
 res.send(page("Your servers",body,req.session.user));
});
app.get("/servers/:id",requireAuth,(req,res)=>{
 const g=(req.session.guilds||[]).find(x=>x.id===req.params.id);if(!g)return res.status(403).send(page("Forbidden","<h1>Access denied</h1>",req.session.user));
 const c=guildConfig(g.id), fields=[
 ["logChannelId","General log channel ID"],["modLogChannelId","Moderation log channel ID"],["welcomeChannelId","Welcome channel ID"],["goodbyeChannelId","Goodbye channel ID"],
 ["ticketCategoryId","Ticket category ID"],["quarantineRoleId","Quarantine role ID"],["verifiedRoleId","Verified role ID"],["unverifiedRoleId","Unverified role ID"]
 ];
 const inputs=fields.map(([key,label])=>`<label>${label}<input name="${key}" value="${esc(c[key]||"")}" placeholder="Leave blank to disable"></label>`).join("");
 const body=`<p><a href="/servers">← Servers</a></p><h1>${esc(g.name)} settings</h1><form method="post" action="/servers/${esc(g.id)}">
 <section class="card"><h2>Channels and roles</h2>${inputs}<label>Staff role IDs (comma separated)<input name="staffRoleIds" value="${esc((c.staffRoleIds||[]).join(","))}"></label><label>Ticket support role IDs (comma separated)<input name="ticketSupportRoleIds" value="${esc((c.ticketSupportRoleIds||[]).join(","))}"></label><label>Auto role IDs (comma separated)<input name="autoRoleIds" value="${esc((c.autoRoleIds||[]).join(","))}"></label></section>
 <section class="card"><h2>Safety</h2><label><input style="width:auto;display:inline" type="checkbox" name="antiSpamEnabled" ${c.antiSpam?.enabled?"checked":""}> Enable anti-spam</label><label>Messages per window<input type="number" min="3" max="30" name="maxMessages" value="${esc(c.antiSpam?.maxMessages||6)}"></label><label>Spam window (seconds)<input type="number" min="3" max="60" name="windowSeconds" value="${esc(c.antiSpam?.windowSeconds||7)}"></label><label>Timeout duration (minutes)<input type="number" min="1" max="1440" name="timeoutMinutes" value="${esc(c.antiSpam?.timeoutMinutes||5)}"></label><label><input style="width:auto;display:inline" type="checkbox" name="antiRaidEnabled" ${c.antiRaid?.enabled?"checked":""}> Enable anti-raid join alerts</label><label>Join threshold<input type="number" min="3" max="100" name="joinThreshold" value="${esc(c.antiRaid?.joinThreshold||8)}"></label><label><input style="width:auto;display:inline" type="checkbox" name="antiNukeEnabled" ${c.antiNuke?.enabled?"checked":""}> Enable anti-nuke alerts</label><p class="muted">Anti-nuke response stays on alert in this dashboard for safety. Test before enabling any automatic enforcement in config files.</p></section>
 <button type="submit">Save settings</button></form>`;
 res.send(page("Server settings",body,req.session.user));
});
app.post("/servers/:id",requireAuth,(req,res)=>{
 const g=(req.session.guilds||[]).find(x=>x.id===req.params.id);if(!g)return res.status(403).send("Forbidden");
 const c=guildConfig(g.id),trim=x=>String(x||"").trim(),list=x=>trim(x).split(",").map(s=>s.trim()).filter(Boolean);
 for(const key of ["logChannelId","modLogChannelId","welcomeChannelId","goodbyeChannelId","ticketCategoryId","quarantineRoleId","verifiedRoleId","unverifiedRoleId"])c[key]=trim(req.body[key]);
 c.staffRoleIds=list(req.body.staffRoleIds);c.ticketSupportRoleIds=list(req.body.ticketSupportRoleIds);c.autoRoleIds=list(req.body.autoRoleIds);
 c.antiSpam={...(c.antiSpam||{}),enabled:req.body.antiSpamEnabled==="on",maxMessages:Math.max(3,Math.min(30,Number(req.body.maxMessages)||6)),windowSeconds:Math.max(3,Math.min(60,Number(req.body.windowSeconds)||7)),timeoutMinutes:Math.max(1,Math.min(1440,Number(req.body.timeoutMinutes)||5))};
 c.antiRaid={...(c.antiRaid||{}),enabled:req.body.antiRaidEnabled==="on",joinThreshold:Math.max(3,Math.min(100,Number(req.body.joinThreshold)||8))};
 c.antiNuke={...(c.antiNuke||{}),enabled:req.body.antiNukeEnabled==="on",action:"alert"};
 storage.saveConfig(g.id,c);
 res.send(page("Settings saved",`<section class="card"><h1>✅ Settings saved</h1><p>Saved settings for ${esc(g.name)}.</p><p>Changes are read by the bot on subsequent events/commands.</p><a href="/servers/${esc(g.id)}">Back to settings</a></section>`,req.session.user));
});
app.get("/logout",(req,res)=>req.session.destroy(()=>res.redirect("/")));
app.listen(PORT,()=>console.log(`Dashboard listening at ${base}`));

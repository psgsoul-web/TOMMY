const fs = require("node:fs");
const path = require("node:path");
const dir = path.join(__dirname, "..", "data");
const storeFile = path.join(dir, "store.json");
const configFile = path.join(dir, "guild-configs.json");
function ensure() {
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  if (!fs.existsSync(storeFile)) fs.writeFileSync(storeFile, JSON.stringify({ users: {}, tickets: {}, voiceSessions: {}, modCases: [], verification: {} }, null, 2));
  if (!fs.existsSync(configFile)) fs.writeFileSync(configFile, JSON.stringify({}, null, 2));
}
function readStore() { ensure(); try { return JSON.parse(fs.readFileSync(storeFile, "utf8")); } catch { return { users: {}, tickets: {}, voiceSessions: {}, modCases: [], verification: {} }; } }
function writeStore(data) { ensure(); fs.writeFileSync(storeFile, JSON.stringify(data, null, 2)); }
function readConfigs() { ensure(); try { return JSON.parse(fs.readFileSync(configFile, "utf8")); } catch { return {}; } }
function writeConfigs(data) { ensure(); fs.writeFileSync(configFile, JSON.stringify(data, null, 2)); }
function getConfig(guildId, defaults) {
  const all = readConfigs();
  return { ...defaults, ...(all[guildId] || {}) };
}
function saveConfig(guildId, config) {
  const all = readConfigs(); all[guildId] = config; writeConfigs(all);
}
function updateUser(guildId, userId, fn) {
  const db = readStore();
  db.users[guildId] ||= {};
  db.users[guildId][userId] ||= { xp: 0, messages: 0, voiceMinutes: 0 };
  fn(db.users[guildId][userId]); writeStore(db); return db.users[guildId][userId];
}
function addCase(item) {
  const db = readStore(); db.modCases ||= [];
  item.caseId = (db.modCases.at(-1)?.caseId || 0) + 1;
  db.modCases.push(item); if (db.modCases.length > 1000) db.modCases = db.modCases.slice(-1000);
  writeStore(db); return item.caseId;
}
module.exports = { readStore, writeStore, readConfigs, writeConfigs, getConfig, saveConfig, updateUser, addCase };

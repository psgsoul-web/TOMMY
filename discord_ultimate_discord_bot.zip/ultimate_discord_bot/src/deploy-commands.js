require("dotenv").config();
const { REST, Routes } = require("discord.js");
const commands = require("./commands");
if (!process.env.DISCORD_TOKEN || !process.env.CLIENT_ID || !process.env.GUILD_ID) throw new Error("Set DISCORD_TOKEN, CLIENT_ID, GUILD_ID in .env");
const rest = new REST({ version: "10" }).setToken(process.env.DISCORD_TOKEN);
(async()=>{ await rest.put(Routes.applicationGuildCommands(process.env.CLIENT_ID, process.env.GUILD_ID), { body: commands }); console.log(`Registered ${commands.length} commands.`); })().catch(e=>{ console.error(e); process.exitCode=1; });

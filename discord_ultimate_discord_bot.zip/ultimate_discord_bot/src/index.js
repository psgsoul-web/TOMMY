require("dotenv").config();
const {
  Client, GatewayIntentBits, Partials, Events, EmbedBuilder, ActionRowBuilder, ButtonBuilder,
  ButtonStyle, ChannelType, PermissionsBitField, AuditLogEvent, ModalBuilder, TextInputBuilder,
  TextInputStyle, AttachmentBuilder
} = require("discord.js");
const { guildConfig } = require("./config");
const storage = require("./storage");
if (!process.env.DISCORD_TOKEN) throw new Error("Missing DISCORD_TOKEN in .env");
const client = new Client({ intents: [
  GatewayIntentBits.Guilds, GatewayIntentBits.GuildMembers, GatewayIntentBits.GuildMessages,
  GatewayIntentBits.MessageContent, GatewayIntentBits.GuildVoiceStates, GatewayIntentBits.GuildMessageReactions,
  GatewayIntentBits.GuildPresences
], partials: [Partials.Message, Partials.Channel, Partials.Reaction] });
const P = PermissionsBitField.Flags;
const spam = new Map(), joins = new Map(), nuke = new Map(), xpCooldown = new Map(), repeats = new Map();

function staff(member, cfg) { return Boolean(member?.permissions?.has(P.Administrator) || member?.roles?.cache?.some(r => (cfg.staffRoleIds||[]).includes(r.id))); }
async function log(guild, title, description, color=0x5865F2, mod=false) {
  if (!guild) return;
  const cfg = guildConfig(guild.id), id = (mod && cfg.modLogChannelId) || cfg.logChannelId;
  if (!id) return;
  const ch = guild.channels.cache.get(id) || await guild.channels.fetch(id).catch(()=>null);
  if (ch?.isTextBased()) ch.send({ embeds:[new EmbedBuilder().setTitle(title).setDescription(String(description).slice(0,3800)).setColor(color).setTimestamp()] }).catch(()=>{});
}
async function dm(user, title, body) {
  try { await user.send({ embeds:[new EmbedBuilder().setTitle(title).setDescription(body).setColor(0xED4245).setTimestamp()] }); return true; } catch { return false; }
}
function rank(xp) {
  let level=0, remaining=xp; const next=n=>5*n*n+50*n+100;
  while (remaining>=next(level)) { remaining-=next(level); level++; }
  return { level, current:remaining, next:next(level) };
}
async function reply(i, content, ephemeral=true) {
  if (i.deferred || i.replied) return i.followUp({content,ephemeral}).catch(()=>{});
  return i.reply({content,ephemeral}).catch(()=>{});
}
async function audit(guild,type,targetId) {
  try {
    const logs=await guild.fetchAuditLogs({type,limit:6});
    return logs.entries.find(e=>(!targetId||e.target?.id===targetId) && Date.now()-e.createdTimestamp<15000);
  } catch { return null; }
}
async function nukeGuard(guild, eventName, targetId, auditType) {
  const cfg=guildConfig(guild.id), ac=cfg.antiNuke||{}; if(!ac.enabled) return;
  const entry=await audit(guild,auditType,targetId);
  if(!entry?.executor||entry.executor.bot||(ac.protectedUserIds||[]).includes(entry.executor.id)) return;
  const key=`${guild.id}:${entry.executor.id}:${eventName}`, now=Date.now();
  const arr=(nuke.get(key)||[]).filter(t=>now-t<(ac.windowSeconds||20)*1000); arr.push(now); nuke.set(key,arr);
  if(arr.length<(ac.threshold||3)) return;
  await log(guild,"🚨 Anti-nuke alert",`${arr.length} ${eventName} events in ${ac.windowSeconds||20}s.\nExecutor: ${entry.executor.tag} (${entry.executor.id})\nResponse: ${ac.action||"alert"}`,0xED4245,true);
  if(ac.action==="kick" && entry.executor.id!==guild.ownerId) {
    const member=await guild.members.fetch(entry.executor.id).catch(()=>null);
    if(member && !member.permissions.has(P.Administrator)) await member.kick(`Anti-nuke: suspicious ${eventName} burst`).catch(()=>{});
  }
  nuke.set(key,[]);
}
async function closeTicket(i) {
  const db=storage.readStore(), ticket=db.tickets[i.channelId], cfg=guildConfig(i.guild.id);
  if(!ticket) return reply(i,"This is not a tracked ticket.");
  if(ticket.ownerId!==i.user.id && !staff(i.member,cfg)) return reply(i,"Only the ticket owner or staff can close this ticket.");
  await reply(i,"Closing ticket. Transcript will be logged if configured.");
  if(cfg.ticket?.transcriptOnClose) {
    try {
      const msgs=await i.channel.messages.fetch({limit:100});
      const rows=[...msgs.values()].sort((a,b)=>a.createdTimestamp-b.createdTimestamp);
      const esc=s=>String(s).replace(/[&<>"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));
      const html=`<!doctype html><html><head><meta charset="utf-8"><title>Ticket transcript</title><style>body{font-family:system-ui;background:#111827;color:#e5e7eb;padding:2rem}article{border-bottom:1px solid #374151;padding:.7rem}small{color:#9ca3af}</style></head><body><h1>Transcript: ${esc(i.channel.name)}</h1>${rows.map(m=>`<article><small>${new Date(m.createdTimestamp).toISOString()} · ${esc(m.author.tag)}</small><div>${esc(m.content||"[embed or attachment]")}</div></article>`).join("")}</body></html>`;
      const file=new AttachmentBuilder(Buffer.from(html),{name:`transcript-${i.channel.id}.html`});
      const logId=cfg.modLogChannelId||cfg.logChannelId, ch=logId&&i.guild.channels.cache.get(logId);
      if(ch?.isTextBased()) await ch.send({content:`Ticket transcript — owner <@${ticket.ownerId}>, closed by <@${i.user.id}>`,files:[file]}).catch(()=>{});
    } catch(e) { console.error("Transcript error",e); }
  }
  delete db.tickets[i.channelId]; storage.writeStore(db);
  setTimeout(()=>i.channel.delete("Ticket closed").catch(()=>{}),Math.max(1,cfg.ticket?.deleteDelaySeconds||5)*1000);
}
client.once(Events.ClientReady,c=>console.log(`Ultimate bot online as ${c.user.tag}`));

client.on(Events.GuildMemberAdd,async member=>{
  const cfg=guildConfig(member.guild.id);
  for(const id of cfg.autoRoleIds||[]) { const role=member.guild.roles.cache.get(id); if(role) await member.roles.add(role,"Configured auto-role").catch(()=>{}); }
  const ar=cfg.antiRaid||{}, now=Date.now(), key=member.guild.id;
  const arr=(joins.get(key)||[]).filter(t=>now-t<(ar.windowSeconds||15)*1000); arr.push(now); joins.set(key,arr);
  if(ar.enabled&&arr.length>=(ar.joinThreshold||8)) {
    await log(member.guild,"🚨 Possible raid",`${arr.length} joins within ${ar.windowSeconds||15} seconds.`,0xED4245,true);
    if(ar.action==="quarantine"&&ar.quarantineRoleId) { const role=member.guild.roles.cache.get(ar.quarantineRoleId); if(role) await member.roles.add(role,"Anti-raid response").catch(()=>{}); }
  }
  const ch=cfg.welcomeChannelId&&member.guild.channels.cache.get(cfg.welcomeChannelId);
  if(ch?.isTextBased()) ch.send(`Welcome ${member} to **${member.guild.name}**!`).catch(()=>{});
  await log(member.guild,"Member joined",`${member.user.tag} (${member.id}) joined.`,0x57F287);
});
client.on(Events.GuildMemberRemove,async member=>{
  const cfg=guildConfig(member.guild.id), ch=cfg.goodbyeChannelId&&member.guild.channels.cache.get(cfg.goodbyeChannelId);
  if(ch?.isTextBased()) ch.send(`${member.user.tag} has left the server.`).catch(()=>{});
  await log(member.guild,"Member left",`${member.user.tag} (${member.id}) left.`,0xFEE75C);
});
client.on(Events.MessageCreate,async m=>{
  if(!m.guild||m.author.bot) return;
  const cfg=guildConfig(m.guild.id), ac=cfg.antiSpam||{}, key=`${m.guild.id}:${m.author.id}`, now=Date.now();
  if(ac.enabled&&!staff(m.member,cfg)&&!(ac.ignoreRoleIds||[]).some(id=>m.member?.roles.cache.has(id))) {
    const arr=(spam.get(key)||[]).filter(t=>now-t<(ac.windowSeconds||7)*1000); arr.push(now); spam.set(key,arr);
    const text=m.content.toLowerCase().trim(), prev=repeats.get(key)||[], duplicates=[...prev,text].filter(s=>s&&s===text).length;
    repeats.set(key,[...prev,text].slice(-10));
    const links=(m.content.match(/https?:\/\/\S+/gi)||[]).length, mentions=m.mentions.users.size+m.mentions.roles.size;
    let why="";
    if(arr.length>(ac.maxMessages||6)) why="message burst";
    else if(duplicates>=(ac.duplicateThreshold||4)) why="repeated messages";
    else if(mentions>(ac.maxMentions||6)) why="excessive mentions";
    else if(links>(ac.maxLinks||5)) why="excessive links";
    if(why) {
      await m.delete().catch(()=>{});
      await log(m.guild,"🛡️ Anti-spam",`${m.author.tag} in ${m.channel}: ${why}`,0xED4245,true);
      if(m.member?.moderatable) {
        await m.member.timeout((ac.timeoutMinutes||5)*60000,`Anti-spam: ${why}`).catch(()=>{});
        await dm(m.author,"Temporary timeout",`Server: ${m.guild.name}\nReason: ${why}\nDuration: ${ac.timeoutMinutes||5} minutes.`);
      }
      spam.delete(key); repeats.delete(key); return;
    }
  }
  storage.updateUser(m.guild.id,m.author.id,u=>{u.messages++;});
  if(now-(xpCooldown.get(key)||0)>=(cfg.levels?.messageXpCooldownSeconds||60)*1000) {
    const min=cfg.levels?.xpPerMessageMin||8,max=Math.max(min,cfg.levels?.xpPerMessageMax||15);
    storage.updateUser(m.guild.id,m.author.id,u=>{u.xp+=Math.floor(Math.random()*(max-min+1))+min;});
    xpCooldown.set(key,now);
  }
});
client.on(Events.VoiceStateUpdate,(oldS,newS)=>{
  const member=newS.member||oldS.member; if(!member||member.user.bot) return;
  const db=storage.readStore(); db.voiceSessions||={}; const key=`${member.guild.id}:${member.id}`;
  if(!oldS.channelId&&newS.channelId) db.voiceSessions[key]=Date.now();
  if(oldS.channelId&&!newS.channelId&&db.voiceSessions[key]) {
    const mins=Math.floor((Date.now()-db.voiceSessions[key])/60000), cfg=guildConfig(member.guild.id);
    if(mins>0) storage.updateUser(member.guild.id,member.id,u=>{u.voiceMinutes+=mins;u.xp+=mins*(cfg.levels?.voiceXpPerMinute||2);});
    delete db.voiceSessions[key];
  }
  storage.writeStore(db);
});
client.on(Events.MessageReactionAdd,async(r,u)=>{
  if(u.bot)return; if(r.partial)await r.fetch().catch(()=>null);
  const g=r.message.guild; if(!g)return; const cfg=guildConfig(g.id);
  if(r.message.id!==cfg.reactionRoleMessageId)return;
  const id=cfg.reactionRoles?.[r.emoji.name], role=id&&g.roles.cache.get(id), member=await g.members.fetch(u.id).catch(()=>null);
  if(member&&role)member.roles.add(role,"Reaction role").catch(()=>{});
});
client.on(Events.MessageReactionRemove,async(r,u)=>{
  if(u.bot)return; if(r.partial)await r.fetch().catch(()=>null);
  const g=r.message.guild; if(!g)return; const cfg=guildConfig(g.id);
  if(r.message.id!==cfg.reactionRoleMessageId)return;
  const id=cfg.reactionRoles?.[r.emoji.name], role=id&&g.roles.cache.get(id), member=await g.members.fetch(u.id).catch(()=>null);
  if(member&&role)member.roles.remove(role,"Reaction role removed").catch(()=>{});
});

client.on(Events.InteractionCreate,async i=>{
  try {
    if(i.isButton()) {
      if(i.customId==="ticket_create") {
        const cfg=guildConfig(i.guild.id), db=storage.readStore();
        const found=Object.entries(db.tickets).find(([id,t])=>t.ownerId===i.user.id&&t.guildId===i.guild.id&&i.guild.channels.cache.has(id));
        if(found)return reply(i,`You already have a ticket: <#${found[0]}>`);
        const perms=[{id:i.guild.roles.everyone.id,deny:[P.ViewChannel]},{id:i.user.id,allow:[P.ViewChannel,P.SendMessages,P.ReadMessageHistory,P.AttachFiles]},{id:client.user.id,allow:[P.ViewChannel,P.SendMessages,P.ManageChannels,P.ReadMessageHistory]}];
        for(const id of [...(cfg.ticketSupportRoleIds||[]),...(cfg.staffRoleIds||[])])perms.push({id,allow:[P.ViewChannel,P.SendMessages,P.ReadMessageHistory]});
        const ch=await i.guild.channels.create({name:`ticket-${i.user.username}`.toLowerCase().replace(/[^a-z0-9-]/g,"-").slice(0,85),type:ChannelType.GuildText,parent:cfg.ticketCategoryId||undefined,permissionOverwrites:perms}).catch(()=>null);
        if(!ch)return reply(i,"Ticket creation failed. Check Manage Channels and configuration.");
        db.tickets[ch.id]={ownerId:i.user.id,guildId:i.guild.id,openedAt:Date.now(),claimedBy:null};storage.writeStore(db);
        await ch.send({content:`${i.user} Please describe your issue. Staff can use /ticket-claim, /ticket-add, and /ticket-remove.`,components:[new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId("ticket_close_button").setLabel("Close ticket").setStyle(ButtonStyle.Danger))]});
        return reply(i,`Ticket created: ${ch}`);
      }
      if(i.customId==="ticket_close_button")return closeTicket(i);
      if(i.customId==="verify_start") {
        const cfg=guildConfig(i.guild.id), a=Math.floor(Math.random()*8)+2,b=Math.floor(Math.random()*8)+2;
        const modal=new ModalBuilder().setCustomId(`verify_math_${a}_${b}`).setTitle("Quick verification");
        modal.addComponents(new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId("answer").setLabel(`What is ${a} + ${b}?`).setStyle(TextInputStyle.Short).setRequired(true).setMaxLength(3)));
        return i.showModal(modal);
      }
      return;
    }
    if(i.isModalSubmit()&&i.customId.startsWith("verify_math_")) {
      const [, , a, b]=i.customId.split("_"), answer=Number(i.fields.getTextInputValue("answer"));
      if(answer!==Number(a)+Number(b))return reply(i,"Incorrect answer. Click Verify and try again.");
      const cfg=guildConfig(i.guild.id), roleId=cfg.verifiedRoleId, role=roleId&&i.guild.roles.cache.get(roleId);
      if(!role)return reply(i,"Verification passed, but the verifiedRoleId is not configured.");
      const member=await i.guild.members.fetch(i.user.id).catch(()=>null);
      if(!member)return reply(i,"Could not find your server membership.");
      await member.roles.add(role,"Completed verification").catch(()=>{});
      if(cfg.unverifiedRoleId)await member.roles.remove(cfg.unverifiedRoleId,"Completed verification").catch(()=>{});
      return reply(i,"✅ Verification successful. Welcome!");
    }
    if(!i.isChatInputCommand())return;
    const cfg=guildConfig(i.guild.id), cmd=i.commandName, reason=i.options.getString("reason")||`Action by ${i.user.tag}`;
    if(["kick","ban","unban","timeout","removetimeout","quarantine","removequarantine"].includes(cmd)) {
      let user, targetId, label=cmd;
      if(cmd==="unban") {
        targetId=i.options.getString("userid"); await i.guild.members.unban(targetId,reason);
      } else {
        user=i.options.getUser("user"); targetId=user.id;
        const member=await i.guild.members.fetch(targetId).catch(()=>null);
        if(!member)return reply(i,"That user is not in this server.");
        if([i.guild.ownerId,i.user.id].includes(targetId))return reply(i,"You cannot moderate yourself or the server owner.");
        if(cmd==="kick")await member.kick(reason);
        if(cmd==="ban")await i.guild.members.ban(targetId,{reason});
        if(cmd==="timeout")await member.timeout(i.options.getInteger("minutes")*60000,reason);
        if(cmd==="removetimeout"){await member.timeout(null,reason);label="remove timeout";}
        if(cmd==="quarantine"||cmd==="removequarantine"){
          const roleId=cfg.quarantineRoleId||cfg.antiRaid?.quarantineRoleId,role=roleId&&i.guild.roles.cache.get(roleId);
          if(!role)return reply(i,"Configure quarantineRoleId first.");
          if(cmd==="quarantine")await member.roles.add(role,reason);else await member.roles.remove(role,reason);
        }
      }
      const caseId=storage.addCase({guildId:i.guild.id,action:label,targetId,moderatorId:i.user.id,reason,at:Date.now()});
      if(user)await dm(user,`Moderation notice: ${label}`,`Server: ${i.guild.name}\nAction: ${label}\nReason: ${reason}\nCase #${caseId}`);
      await reply(i,`${label} completed. Case #${caseId}.`);
      return log(i.guild,`Case #${caseId}: ${label}`,`Target: ${user?.tag||targetId}\nModerator: ${i.user.tag}\nReason: ${reason}`,0xED4245,true);
    }
    if(cmd==="dm"){await i.options.getUser("user").send(i.options.getString("message"));return reply(i,"DM sent.");}
    if(cmd==="say"){await i.channel.send(i.options.getString("message"));return reply(i,"Message sent.");}
    if(cmd==="announce"){const ch=i.options.getChannel("channel")||i.channel;await ch.send({embeds:[new EmbedBuilder().setTitle("📢 Announcement").setDescription(i.options.getString("message")).setColor(0x5865F2).setFooter({text:`Posted by ${i.user.tag}`}).setTimestamp()]});return reply(i,`Announcement posted in ${ch}.`);}
    if(cmd==="ticket-panel"){await i.channel.send({embeds:[new EmbedBuilder().setTitle("🎫 Support").setDescription("Press below to open a private ticket.").setColor(0x5865F2)],components:[new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId("ticket_create").setLabel("Create ticket").setStyle(ButtonStyle.Primary))]});return reply(i,"Ticket panel posted.");}
    if(cmd.startsWith("ticket-")){
      const db=storage.readStore(),t=db.tickets[i.channelId];if(!t)return reply(i,"This is not a tracked ticket.");
      if(cmd==="ticket-close")return closeTicket(i);
      if(cmd==="ticket-claim"){if(!staff(i.member,cfg))return reply(i,"Staff only.");t.claimedBy=i.user.id;db.tickets[i.channelId]=t;storage.writeStore(db);await i.channel.send(`Ticket claimed by ${i.user}.`);return reply(i,"Ticket claimed.");}
      if(cmd==="ticket-add"||cmd==="ticket-remove"){
        if(!staff(i.member,cfg))return reply(i,"Staff only.");const u=i.options.getUser("user");
        await i.channel.permissionOverwrites.edit(u.id,cmd==="ticket-add"?{ViewChannel:true,SendMessages:true,ReadMessageHistory:true}:{ViewChannel:false,SendMessages:false,ReadMessageHistory:false});
        await i.channel.send(`${u} ${cmd==="ticket-add"?"added to":"removed from"} ticket by ${i.user}.`);return reply(i,"Ticket access updated.");
      }
    }
    if(cmd==="rank"){const u=i.options.getUser("user")||i.user,db=storage.readStore(),v=db.users[i.guild.id]?.[u.id]||{xp:0,messages:0,voiceMinutes:0},r=rank(v.xp);return reply(i,`**${u.username}** — Level ${r.level}\nXP ${v.xp} (${r.current}/${r.next})\nMessages ${v.messages||0} · Voice minutes ${v.voiceMinutes||0}`);}
    if(cmd==="leaderboard"){const entries=Object.entries(storage.readStore().users[i.guild.id]||{}).sort((a,b)=>b[1].xp-a[1].xp).slice(0,10);const lines=await Promise.all(entries.map(async([id,u,n])=>`${entries.findIndex(x=>x[0]===id)+1}. ${(await client.users.fetch(id).catch(()=>null))?.username||id} — ${u.xp} XP (Level ${rank(u.xp).level})`));return reply(i,lines.join("\n")||"No XP recorded yet.");}
    if(cmd==="admin-panel"){const members=await i.guild.members.fetch();const lines=members.filter(m=>(cfg.staffRoleIds||[]).some(id=>m.roles.cache.has(id))).map(m=>`${m.presence&&m.presence.status!=="offline"?"🟢 Online":"⚫ Offline/unknown"} — ${m.user.tag}`).slice(0,35);return i.reply({embeds:[new EmbedBuilder().setTitle("Staff status snapshot").setDescription(lines.join("\n")||"Configure staffRoleIds.").setColor(0x5865F2)],ephemeral:true});}
    if(cmd==="reaction-role-setup"){const ch=i.guild.channels.cache.get(cfg.reactionRoleChannelId||i.channelId);if(!ch?.isTextBased())return reply(i,"Configure reactionRoleChannelId.");const body=Object.entries(cfg.reactionRoles||{}).map(([e,id])=>`${e} — <@&${id}>`).join("\n");const msg=await ch.send({embeds:[new EmbedBuilder().setTitle("Reaction Roles").setDescription(body||"No roles configured.").setColor(0x5865F2)]});for(const e of Object.keys(cfg.reactionRoles||{}))await msg.react(e).catch(()=>{});cfg.reactionRoleMessageId=msg.id;require("./storage").saveConfig(i.guild.id,cfg);return reply(i,`Reaction role panel posted: ${msg.url}`);}
    if(cmd==="verification-panel"){await i.channel.send({embeds:[new EmbedBuilder().setTitle("🔐 Server Verification").setDescription("Click Verify and answer the quick math question to unlock the server.").setColor(0x57F287)],components:[new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId("verify_start").setLabel("Verify").setStyle(ButtonStyle.Success))]});return reply(i,"Verification panel posted.");}
  } catch(e) {
    console.error("Interaction error",e);
    await log(i.guild,"Bot error",`${i.commandName||i.customId}: ${String(e).slice(0,1200)}`,0xED4245,true);
    return reply(i,`Action failed. Check permissions, role hierarchy and config. (${String(e.message||e).slice(0,120)})`);
  }
});
client.on(Events.ChannelDelete,ch=>{if(!ch.guild)return;log(ch.guild,"Channel deleted",`${ch.name} (${ch.id})`,0xED4245,true);nukeGuard(ch.guild,"channel deletion",ch.id,AuditLogEvent.ChannelDelete).catch(()=>{});const db=storage.readStore();delete db.tickets[ch.id];storage.writeStore(db);});
client.on(Events.ChannelCreate,ch=>ch.guild&&log(ch.guild,"Channel created",`${ch.name} (${ch.id})`));
client.on(Events.GuildRoleDelete,r=>{log(r.guild,"Role deleted",`${r.name} (${r.id})`,0xED4245,true);nukeGuard(r.guild,"role deletion",r.id,AuditLogEvent.RoleDelete).catch(()=>{});});
client.on(Events.GuildRoleCreate,r=>log(r.guild,"Role created",`${r.name} (${r.id})`));
client.on(Events.GuildBanAdd,b=>{log(b.guild,"Member banned",`${b.user.tag} (${b.user.id})`,0xED4245,true);nukeGuard(b.guild,"member ban",b.user.id,AuditLogEvent.MemberBanAdd).catch(()=>{});});
client.on(Events.GuildBanRemove,b=>log(b.guild,"Member unbanned",`${b.user.tag} (${b.user.id})`,0x57F287,true));
client.on(Events.GuildMemberUpdate,(o,n)=>{if(o.nickname!==n.nickname)log(n.guild,"Nickname updated",`${n.user.tag}: ${o.nickname||o.user.username} → ${n.nickname||n.user.username}`);});
client.login(process.env.DISCORD_TOKEN);

const { SlashCommandBuilder, PermissionFlagsBits, ChannelType } = require("discord.js");
const P = PermissionFlagsBits;
const commands = [
  new SlashCommandBuilder().setName("kick").setDescription("Kick a member").setDefaultMemberPermissions(P.KickMembers).addUserOption(o=>o.setName("user").setDescription("Member").setRequired(true)).addStringOption(o=>o.setName("reason").setDescription("Reason")),
  new SlashCommandBuilder().setName("ban").setDescription("Ban a member").setDefaultMemberPermissions(P.BanMembers).addUserOption(o=>o.setName("user").setDescription("Member").setRequired(true)).addStringOption(o=>o.setName("reason").setDescription("Reason")),
  new SlashCommandBuilder().setName("unban").setDescription("Unban a user ID").setDefaultMemberPermissions(P.BanMembers).addStringOption(o=>o.setName("userid").setDescription("User ID").setRequired(true)).addStringOption(o=>o.setName("reason").setDescription("Reason")),
  new SlashCommandBuilder().setName("timeout").setDescription("Timeout a member").setDefaultMemberPermissions(P.ModerateMembers).addUserOption(o=>o.setName("user").setDescription("Member").setRequired(true)).addIntegerOption(o=>o.setName("minutes").setDescription("1-40320 minutes").setRequired(true).setMinValue(1).setMaxValue(40320)).addStringOption(o=>o.setName("reason").setDescription("Reason")),
  new SlashCommandBuilder().setName("removetimeout").setDescription("Remove timeout").setDefaultMemberPermissions(P.ModerateMembers).addUserOption(o=>o.setName("user").setDescription("Member").setRequired(true)),
  new SlashCommandBuilder().setName("quarantine").setDescription("Apply quarantine role").setDefaultMemberPermissions(P.ManageRoles).addUserOption(o=>o.setName("user").setDescription("Member").setRequired(true)).addStringOption(o=>o.setName("reason").setDescription("Reason")),
  new SlashCommandBuilder().setName("removequarantine").setDescription("Remove quarantine role").setDefaultMemberPermissions(P.ManageRoles).addUserOption(o=>o.setName("user").setDescription("Member").setRequired(true)),
  new SlashCommandBuilder().setName("dm").setDescription("DM a user").setDefaultMemberPermissions(P.ManageMessages).addUserOption(o=>o.setName("user").setDescription("Recipient").setRequired(true)).addStringOption(o=>o.setName("message").setDescription("Message").setRequired(true).setMaxLength(1800)),
  new SlashCommandBuilder().setName("say").setDescription("Send a message as bot").setDefaultMemberPermissions(P.ManageMessages).addStringOption(o=>o.setName("message").setDescription("Message").setRequired(true).setMaxLength(1800)),
  new SlashCommandBuilder().setName("announce").setDescription("Post announcement").setDefaultMemberPermissions(P.ManageGuild).addStringOption(o=>o.setName("message").setDescription("Announcement").setRequired(true).setMaxLength(1800)).addChannelOption(o=>o.setName("channel").setDescription("Destination").addChannelTypes(ChannelType.GuildText)),
  new SlashCommandBuilder().setName("ticket-panel").setDescription("Post ticket panel").setDefaultMemberPermissions(P.ManageChannels),
  new SlashCommandBuilder().setName("ticket-close").setDescription("Close this ticket"),
  new SlashCommandBuilder().setName("ticket-claim").setDescription("Claim this ticket"),
  new SlashCommandBuilder().setName("ticket-add").setDescription("Add user to ticket").setDefaultMemberPermissions(P.ManageChannels).addUserOption(o=>o.setName("user").setDescription("User").setRequired(true)),
  new SlashCommandBuilder().setName("ticket-remove").setDescription("Remove user from ticket").setDefaultMemberPermissions(P.ManageChannels).addUserOption(o=>o.setName("user").setDescription("User").setRequired(true)),
  new SlashCommandBuilder().setName("rank").setDescription("Show level").addUserOption(o=>o.setName("user").setDescription("User")),
  new SlashCommandBuilder().setName("leaderboard").setDescription("XP leaderboard"),
  new SlashCommandBuilder().setName("admin-panel").setDescription("Staff presence snapshot").setDefaultMemberPermissions(P.ManageGuild),
  new SlashCommandBuilder().setName("reaction-role-setup").setDescription("Post reaction roles").setDefaultMemberPermissions(P.ManageRoles),
  new SlashCommandBuilder().setName("verification-panel").setDescription("Post verification panel").setDefaultMemberPermissions(P.ManageGuild)
];
module.exports = commands.map(c=>c.toJSON());

const fs = require("node:fs");
const path = require("node:path");
const storage = require("./storage");
const file = path.join(__dirname, "..", "config.json");
const raw = JSON.parse(fs.readFileSync(file, "utf8"));
const defaults = raw.default || raw;
function guildConfig(guildId) { return storage.getConfig(guildId, defaults); }
module.exports = { defaults, guildConfig };
